package com.banglaplayer.app

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var subText: TextView
    private lateinit var subBtn: Button
    private lateinit var loadBtn: Button
    private lateinit var bar: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private var cues: List<Cue> = emptyList()
    private var mode = 0 // 0 = off, 1 = English, 2 = Bangla
    private var translating = false
    private var translator: Translator? = null
    private var destroyed = false
    private var resumePos = 0L
    private var resumePlay = true

    private val pickSrt =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadSrt(uri)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.data == null) { finish(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        playerView = PlayerView(this)
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        subText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(10), dp(4), dp(10), dp(4))
            visibility = View.GONE
        }
        val subLp = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        subLp.bottomMargin = dp(90)
        subLp.leftMargin = dp(40); subLp.rightMargin = dp(40)
        root.addView(subText, subLp)

        loadBtn = Button(this).apply {
            text = "Load SRT"
            setOnClickListener { pickSrt.launch(arrayOf("*/*")) }
        }
        subBtn = Button(this).apply {
            text = "Subtitle: Off"
            setOnClickListener { onSubClick() }
        }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(loadBtn)
            addView(subBtn)
        }
        val barLp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        barLp.topMargin = dp(12); barLp.rightMargin = dp(24)
        root.addView(bar, barLp)

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v ->
                bar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
            }
        )

        setContentView(root)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onStart() {
        super.onStart()
        val data: Uri = intent.data ?: return
        val p = ExoPlayer.Builder(this).build()
        playerView.player = p
        p.setMediaItem(MediaItem.fromUri(data))
        p.seekTo(resumePos)
        p.prepare()
        p.playWhenReady = resumePlay
        player = p
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(ticker)
        player?.let {
            resumePos = it.currentPosition
            resumePlay = it.playWhenReady
            it.release()
        }
        player = null
    }

    override fun onDestroy() {
        destroyed = true
        translator?.close()
        super.onDestroy()
    }

    private val ticker = object : Runnable {
        override fun run() {
            val p = player?.currentPosition ?: 0L
            var shown: String? = null
            if (mode != 0) {
                for (c in cues) {
                    if (p >= c.start && p < c.end) {
                        shown = if (mode == 2) (c.bn ?: c.text) else c.text
                        break
                    }
                }
            }
            if (shown == null) {
                subText.visibility = View.GONE
            } else {
                if (subText.text.toString() != shown) subText.text = shown
                subText.visibility = View.VISIBLE
            }
            handler.postDelayed(this, 150)
        }
    }

    private fun updateBtn() {
        subBtn.text = when (mode) {
            1 -> "Subtitle: English"
            2 -> "Subtitle: Bangla"
            else -> "Subtitle: Off"
        }
    }

    private fun onSubClick() {
        if (cues.isEmpty()) { pickSrt.launch(arrayOf("*/*")); return }
        if (translating) {
            Toast.makeText(this, "Translate cholche, ektu opekkha koro", Toast.LENGTH_SHORT).show()
            return
        }
        mode = (mode + 1) % 3
        updateBtn()
    }

    private fun loadSrt(uri: Uri) {
        val text = try {
            contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
        } catch (e: Exception) { null }
        if (text == null) {
            Toast.makeText(this, "File pora gelo na", Toast.LENGTH_SHORT).show()
            return
        }
        val parsed = SrtParser.parse(text)
        if (parsed.isEmpty()) {
            Toast.makeText(this, "SRT file e kono subtitle pawa jayni", Toast.LENGTH_LONG).show()
            return
        }
        cues = parsed
        mode = 1
        startTranslation(parsed)
    }

    private fun startTranslation(list: List<Cue>) {
        translating = true
        translator?.close()
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val tr = Translation.getClient(opts)
        translator = tr
        subBtn.text = "Language pack download..."
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { translateNext(tr, 0, list) }
            .addOnFailureListener {
                translating = false
                updateBtn()
                Toast.makeText(this, "Download hoy nai. Internet check koro", Toast.LENGTH_LONG).show()
            }
    }

    private fun translateNext(tr: Translator, i: Int, list: List<Cue>) {
        if (destroyed || list !== cues) return
        if (i >= list.size) {
            translating = false
            mode = 2
            updateBtn()
            Toast.makeText(this, "Bangla translate shesh!", Toast.LENGTH_SHORT).show()
            return
        }
        if (i % 5 == 0) subBtn.text = "Translating " + (i * 100 / list.size) + "%"
        tr.translate(list[i].text)
            .addOnSuccessListener { list[i].bn = it; translateNext(tr, i + 1, list) }
            .addOnFailureListener { list[i].bn = list[i].text; translateNext(tr, i + 1, list) }
    }
}
