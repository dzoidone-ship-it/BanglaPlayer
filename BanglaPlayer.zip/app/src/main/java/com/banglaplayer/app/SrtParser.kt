package com.banglaplayer.app

data class Cue(val start: Long, val end: Long, val text: String, var bn: String? = null)

object SrtParser {
    private val timeRe = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)")

    fun parse(raw: String): List<Cue> {
        val s = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace("\r", "\n")
        val out = ArrayList<Cue>()
        for (block in s.split(Regex("\n\\s*\n"))) {
            val lines = block.trim().split("\n")
            val idx = lines.indexOfFirst { it.contains("-->") }
            if (idx < 0) continue
            val parts = lines[idx].split("-->")
            if (parts.size < 2) continue
            val st = toMs(parts[0])
            val en = toMs(parts[1])
            if (st < 0 || en < 0) continue
            val text = lines.drop(idx + 1).joinToString("\n")
                .replace(Regex("<[^>]+>"), "")
                .replace(Regex("\\{[^}]*\\}"), "")
                .trim()
            if (text.isNotEmpty()) out.add(Cue(st, en, text))
        }
        return out
    }

    private fun toMs(t: String): Long {
        val m = timeRe.find(t.trim()) ?: return -1
        val (h, mi, sec, ms) = m.destructured
        val msv = ms.padEnd(3, '0').take(3).toLong()
        return h.toLong() * 3600000 + mi.toLong() * 60000 + sec.toLong() * 1000 + msv
    }
}
